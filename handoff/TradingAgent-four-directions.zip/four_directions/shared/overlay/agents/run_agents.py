"""Run one official TradingAgents decision and adapt it to B's CSV contract.

This module deliberately treats the official TradingAgents repository as an
external runtime. It does not copy or reimplement the graph. The only value
that crosses into B's backtest is the final Portfolio Manager rating; analyst,
Trader, and debate opinions remain in the saved report/state logs.

Run from the B-project root:

    python -m agents.run_agents --ticker AAPL --date 2026-07-01

The local framework is installed through the root requirements.txt.
"""

from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import os
import subprocess
import sys
import threading
import time
from datetime import timedelta
from pathlib import Path
from typing import Any

from langchain_core.callbacks import BaseCallbackHandler

from agents.debate_config import DebateOptions
from data import DATA_DIR, ROOT, data_asof, schedule


NY_TZ = "America/New_York"
DEFAULT_ANALYSTS = ("market", "news", "fundamentals")
DEFAULT_STRATEGY = "ta-v0.6.0-deepseek-flash-market-news-fundamentals-v1"
_APPEND_LOCK = threading.Lock()


class ConsoleProgressCallbackHandler(BaseCallbackHandler):
    """Show compact per-decision LLM progress without printing model content."""

    def __init__(self, decision_label: str, heartbeat_seconds: float = 30.0) -> None:
        super().__init__()
        self.decision_label = decision_label
        self.heartbeat_seconds = heartbeat_seconds
        self._lock = threading.Lock()
        self._calls = 0
        self._active: dict[Any, tuple[int, float, str]] = {}
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._heartbeat, daemon=True)
        self._thread.start()

    @staticmethod
    def _stage(kwargs: dict[str, Any]) -> str:
        metadata = kwargs.get("metadata") or {}
        return str(metadata.get("langgraph_node") or kwargs.get("name") or "LLM")

    def _start(self, kwargs: dict[str, Any]) -> None:
        run_id = kwargs.get("run_id") or object()
        with self._lock:
            self._calls += 1
            number = self._calls
            stage = self._stage(kwargs)
            self._active[run_id] = (number, time.monotonic(), stage)
        print(
            f"[decision {self.decision_label}] [LLM step {number}] START {stage}",
            flush=True,
        )

    def on_llm_start(self, serialized, prompts, **kwargs) -> None:
        self._start(kwargs)

    def on_chat_model_start(self, serialized, messages, **kwargs) -> None:
        self._start(kwargs)

    def _finish(self, kwargs: dict[str, Any], status: str) -> None:
        run_id = kwargs.get("run_id")
        with self._lock:
            item = self._active.pop(run_id, None)
        if item is None:
            return
        number, started, stage = item
        elapsed = time.monotonic() - started
        print(
            f"[decision {self.decision_label}] [LLM step {number}] {status} "
            f"{stage} ({elapsed:.1f}s)",
            flush=True,
        )

    def on_llm_end(self, response, **kwargs) -> None:
        self._finish(kwargs, "DONE")

    def on_llm_error(self, error, **kwargs) -> None:
        self._finish(kwargs, f"FAILED {type(error).__name__}")

    def on_tool_start(self, serialized, input_str, **kwargs) -> None:
        name = serialized.get("name", "tool") if isinstance(serialized, dict) else "tool"
        print(f"[decision {self.decision_label}] TOOL START {name}", flush=True)

    def on_tool_end(self, output, **kwargs) -> None:
        print(f"[decision {self.decision_label}] TOOL DONE", flush=True)

    def _heartbeat(self) -> None:
        while not self._stop.wait(self.heartbeat_seconds):
            now = time.monotonic()
            with self._lock:
                active = list(self._active.values())
            for number, started, stage in active:
                print(
                    f"[decision {self.decision_label}] [LLM step {number}] WAITING "
                    f"{stage} ({now - started:.0f}s)",
                    flush=True,
                )

    def close(self) -> None:
        self._stop.set()


def _safe_analysts(value: str | list[str] | tuple[str, ...] | None) -> list[str]:
    names = value if isinstance(value, (list, tuple)) else str(value or "").split(",")
    names = [str(name).strip().lower() for name in names if str(name).strip()]
    allowed = {"market", "social", "news", "fundamentals"}
    unknown = sorted(set(names) - allowed)
    if unknown:
        raise ValueError(f"Unknown analyst(s): {', '.join(unknown)}")
    if not names:
        raise ValueError("At least one analyst is required")
    return list(dict.fromkeys(names))


def _import_official():
    """Import the pinned external runtime only when a real run is requested."""
    try:
        import tradingagents
        from cli.stats_handler import StatsCallbackHandler
        from tradingagents.agents.rating import is_review
        from tradingagents.graph.trading_graph import TradingAgentsGraph
        from tradingagents.default_config import DEFAULT_CONFIG
    except ImportError as exc:
        raise RuntimeError(
            "Official TradingAgents is not installed in this Python environment. "
            "Install this project's requirements.txt (including ./framework), "
            "then rerun the command."
        ) from exc
    return tradingagents, StatsCallbackHandler, is_review, TradingAgentsGraph, DEFAULT_CONFIG


def _build_runtime_config(default_config: dict[str, Any], analysts: list[str], logs_dir: Path) -> dict[str, Any]:
    """Apply course-project defaults without mutating the upstream global config."""
    config = copy.deepcopy(default_config)
    config.update(
        llm_provider=os.getenv("TRADINGAGENTS_LLM_PROVIDER", "deepseek"),
        quick_think_llm=os.getenv("TRADINGAGENTS_QUICK_THINK_LLM", "deepseek-flash"),
        deep_think_llm=os.getenv("TRADINGAGENTS_DEEP_THINK_LLM", "deepseek-flash"),
        output_language=os.getenv("TRADINGAGENTS_OUTPUT_LANGUAGE", "English"),
        max_debate_rounds=int(os.getenv("TRADINGAGENTS_MAX_DEBATE_ROUNDS", "1")),
        max_risk_discuss_rounds=int(os.getenv("TRADINGAGENTS_MAX_RISK_ROUNDS", "1")),
        checkpoint_enabled=os.getenv("TRADINGAGENTS_CHECKPOINT_ENABLED", "true").lower() in {"1", "true", "yes", "on"},
        temperature=float(os.getenv("TRADINGAGENTS_TEMPERATURE", "0.0")),
        llm_max_retries=int(os.getenv("TRADINGAGENTS_LLM_MAX_RETRIES", "2")),
        llm_timeout=float(os.getenv("TRADINGAGENTS_LLM_TIMEOUT_SECONDS", "120")),
        max_tokens=int(os.getenv("TRADINGAGENTS_MAX_TOKENS", "8192")),
        results_dir=str(logs_dir / "results"),
        data_cache_dir=str(logs_dir / "cache"),
        memory_log_path=str(logs_dir / "memory" / "trading_memory.md"),
        news_previous_days_only=True,
        news_company_only=True,
        news_timezone=NY_TZ,
    )
    config["data_vendors"] = {
        **config.get("data_vendors", {}),
        "core_stock_apis": "course_project",
        "technical_indicators": "course_project",
        "fundamental_data": "course_project",
        # Finnhub Company News is the historical company-news source.
        "news_data": "finnhub",
    }
    config["tool_vendors"] = {
        **config.get("tool_vendors", {}),
        "get_insider_transactions": "course_project",
        # Pin the exact source, even if an upstream tool override exists.
        "get_news": "finnhub",
    }
    return config


def _session_cutoff(trade_date: str):
    sessions = schedule(trade_date, trade_date)
    if sessions.empty:
        raise ValueError(f"{trade_date} is not an NYSE trading session")
    close = sessions.iloc[0]["close"]
    cutoff = close.tz_convert(NY_TZ)
    decision_time = cutoff + timedelta(minutes=30)
    return cutoff, decision_time


def _snapshot_manifest(ticker: str, cutoff, data_dir: Path = DATA_DIR) -> dict[str, Any]:
    """Read B's as-of views before any model call and record their sizes/hashes."""
    manifest: dict[str, Any] = {"cutoff": cutoff.isoformat(), "sources": {}}
    for kind in ("prices", "financials"):
        frame = data_asof(ticker, kind, cutoff.isoformat(), data_dir=data_dir)
        payload = frame.to_csv(index=False).encode()
        manifest["sources"][kind] = {
            "rows": int(len(frame)),
            "sha256": hashlib.sha256(payload).hexdigest(),
        }
    return manifest


def _append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with _APPEND_LOCK:
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")


def _record_stats(record: dict[str, Any], stats: Any) -> None:
    usage = stats.get_stats()
    record.update(usage)
    record["input_tokens"] = usage["tokens_in"]
    record["output_tokens"] = usage["tokens_out"]


def _git_state(path: Path) -> dict[str, Any]:
    """Return reproducibility metadata without failing a run outside a checkout."""
    try:
        commit = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=path, check=True,
            capture_output=True, text=True, timeout=5,
        ).stdout.strip()
        dirty = bool(subprocess.run(
            ["git", "status", "--porcelain"], cwd=path, check=True,
            capture_output=True, text=True, timeout=5,
        ).stdout.strip())
        return {"commit": commit, "dirty": dirty}
    except (OSError, subprocess.SubprocessError):
        return {"commit": None, "dirty": None}


def run_one(
    ticker: str,
    trade_date: str,
    *,
    strategy_version: str = DEFAULT_STRATEGY,
    analysts: str | list[str] | tuple[str, ...] | None = None,
    logs_dir: str | Path | None = None,
    data_dir: str | Path = DATA_DIR,
    dry_run: bool = False,
    progress_label: str | None = None,
    debate_options: DebateOptions | None = None,
    frozen_news_snapshot: dict | None = None,
    frozen_past_context: str | None = None,
    extra_callbacks: list | None = None,
) -> dict[str, Any]:
    """Run one `(ticker, trade_date)` cell and return its B-compatible row.

    A failed cell is logged and raised to the batch caller. It never writes a
    partial or guessed decision row.
    """
    try:
        from dotenv import load_dotenv
        load_dotenv(ROOT / ".env", override=False)
    except ImportError:
        pass
    started = time.monotonic()
    ticker = ticker.strip().upper()
    selected = _safe_analysts(analysts or os.getenv("TRADINGAGENTS_ANALYSTS") or DEFAULT_ANALYSTS)
    logs = Path(logs_dir or ROOT / "agents" / "logs")
    record: dict[str, Any] = {
        "run_id": f"{ticker}_{trade_date}_{strategy_version}",
        "strategy_version": strategy_version,
        "ticker": ticker,
        "trade_date": trade_date,
        "analysts": selected,
        "status": "failed",
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "input_tokens": 0,
        "output_tokens": 0,
        "tokens_in": 0,
        "tokens_out": 0,
        "llm_calls": 0,
        "tool_calls": 0,
        "course_project_git": _git_state(ROOT),
    }
    stats = None
    progress = None
    try:
        cutoff, decision_time = _session_cutoff(trade_date)
        # This is the important B/A boundary: if local point-in-time data is
        # absent or malformed, fail before an API call rather than substituting
        # current data or silently producing a non-comparable signal.
        record["data_snapshot"] = _snapshot_manifest(ticker, cutoff, Path(data_dir))
        if debate_options is not None:
            if "social" in selected:
                raise ValueError("Debate-only experiment cannot enable the sentiment analyst")
            record["debate_module"] = debate_options.settings()
            record["max_debate_rounds"] = debate_options.effective_rounds
            record["max_risk_discuss_rounds"] = 1
        if dry_run:
            record.update(status="dry_run", elapsed_seconds=round(time.monotonic() - started, 3))
            _append_jsonl(logs / "runs.jsonl", record)
            return record

        if "news" in selected:
            if frozen_news_snapshot is None and not os.getenv("FINNHUB_API_KEY", "").strip():
                raise ValueError("FINNHUB_API_KEY is empty; set it in the local .env before enabling news")
            if (os.getenv("TRADINGAGENTS_NEWS_VENDOR") or "finnhub").strip().lower() != "finnhub":
                raise ValueError("This experiment requires TRADINGAGENTS_NEWS_VENDOR=finnhub")

        tradingagents, StatsCallbackHandler, is_review, TradingAgentsGraph, default_config = _import_official()
        config = _build_runtime_config(default_config, selected, logs)
        if debate_options is not None:
            config = debate_options.apply(config)
        if frozen_news_snapshot is not None:
            config["finnhub_news_snapshot"] = dict(frozen_news_snapshot)
        if frozen_past_context is not None:
            config["frozen_past_context"] = frozen_past_context
            record["memory_mode"] = "shared_frozen_asof_context"
            record["memory_sha256"] = hashlib.sha256(frozen_past_context.encode()).hexdigest()
        config["news_trade_date"] = trade_date
        if "news" in selected:
            from tradingagents.dataflows.config import run_config
            from tradingagents.dataflows.vendors.finnhub.news import prepare_news_snapshot

            # Fetch and validate before constructing the LLM graph. Tool calls
            # later read this frozen response, including narrower 1-7 day queries.
            with run_config(config):
                snapshot = prepare_news_snapshot(ticker, trade_date)
            config["finnhub_news_snapshot"] = snapshot
            record["data_snapshot"]["sources"]["news"] = snapshot
        official_root = Path(tradingagents.__file__).resolve().parents[1]
        record.update(
            tradingagents_version=tradingagents.__version__,
            tradingagents_git=_git_state(official_root),
            model_provider=config.get("llm_provider"),
            quick_model=config.get("quick_think_llm"),
            deep_model=config.get("deep_think_llm"),
            max_debate_rounds=config.get("max_debate_rounds"),
            max_risk_discuss_rounds=config.get("max_risk_discuss_rounds"),
            temperature=config.get("temperature"),
        )
        stats = StatsCallbackHandler()
        if progress_label:
            progress = ConsoleProgressCallbackHandler(progress_label)
        from agents.local_data_vendor import install as install_local_data_vendor

        install_local_data_vendor(Path(data_dir))
        callbacks = [stats] + ([progress] if progress is not None else []) + list(extra_callbacks or [])
        graph = TradingAgentsGraph(selected, config=config, debug=False, callbacks=callbacks)
        final_state, signal = graph.propagate(ticker, trade_date, asset_type="stock")
        _record_stats(record, stats)
        if debate_options is not None:
            actual = final_state["investment_debate_state"]["count"]
            record["actual_research_turns"] = actual
            if actual != 2 * debate_options.effective_rounds:
                raise ValueError(f"Research debate turn count mismatch: {actual}")
            record["actual_risk_turns"] = final_state["risk_debate_state"]["count"]
            if record["actual_risk_turns"] != 3:
                raise ValueError("Debate-only experiment requires exactly one risk round")
        if is_review(signal):
            raise ValueError("Final Portfolio Manager rating is REVIEW/unparseable")

        # Only the final manager rating crosses into B's binary-position backtest.
        from signals import final_rating, from_final_state

        action = from_final_state(final_state)
        rating = final_rating(final_state)
        reports = logs / "reports" / ticker / trade_date
        reports.mkdir(parents=True, exist_ok=True)
        graph.save_reports(final_state, ticker, save_path=reports, html=True)
        record.update(
            status="success",
            action=action,
            final_rating=rating,
            report_dir=str(reports.relative_to(ROOT)),
            decision_time=decision_time.isoformat(),
            information_cutoff=cutoff.isoformat(),
        )
        row = {
            "ticker": ticker,
            "decision_time": decision_time.isoformat(),
            "information_cutoff": cutoff.isoformat(),
            "action": action,
            "strategy_version": strategy_version,
            "source": "portfolio_manager",
        }
        record["decision_row"] = row
        record["elapsed_seconds"] = round(time.monotonic() - started, 3)
        _append_jsonl(logs / "runs.jsonl", record)
        return record
    except Exception as exc:
        if stats is not None:
            _record_stats(record, stats)
        record.update(
            error_type=type(exc).__name__,
            error=str(exc),
            elapsed_seconds=round(time.monotonic() - started, 3),
        )
        _append_jsonl(logs / "runs.jsonl", record)
        raise
    finally:
        if progress is not None:
            progress.close()


def append_decision(path: str | Path, row: dict[str, str]) -> None:
    """Append one validated row, creating B's required header if necessary."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fields = ["ticker", "decision_time", "information_cutoff", "action", "strategy_version", "source"]
    new_file = not target.exists() or target.stat().st_size == 0
    with target.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        if new_file:
            writer.writeheader()
        writer.writerow({field: row[field] for field in fields})


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run one TradingAgents decision for B's CSV interface")
    parser.add_argument("--ticker", required=True)
    parser.add_argument("--date", required=True, dest="trade_date")
    parser.add_argument("--analysts", default=None, help="Comma-separated; default: market,news,fundamentals")
    parser.add_argument("--strategy-version", default=DEFAULT_STRATEGY)
    parser.add_argument("--output", default=None, help="Optional B decision CSV to append on success")
    parser.add_argument("--dry-run", action="store_true", help="Validate date and local as-of data without calling an LLM")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        result = run_one(
            args.ticker,
            args.trade_date,
            strategy_version=args.strategy_version,
            analysts=args.analysts,
            dry_run=args.dry_run,
        )
        if result.get("status") == "success" and args.output:
            append_decision(args.output, result["decision_row"])
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(f"A run failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
